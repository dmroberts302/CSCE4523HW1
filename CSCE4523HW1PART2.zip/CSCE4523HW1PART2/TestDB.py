import csv
import os.path

from configparser import ConfigParser
from Database import DB


def CreateDB(filename, databaseMethods):
 # generate fileames
 tmpFilename = databaseMethods.RemoveFileExtension(filename)
 csvFilename = tmpFilename + ".csv"
 textFilename = tmpFilename + ".data"
 configFilename = tmpFilename + ".config"
 
 if os.path.isfile(csvFilename):
  # Read the CSV file and write into data files
  with open(csvFilename, "r") as csvFile:
   dataList = list(csv.DictReader(csvFile, fieldnames=('Name', 'Rank', 'City', 'State', 'Zip', 'Employees')))
   
  with open(textFilename, "w") as outfile:
   for dict in dataList:
    databaseMethods.WriteRecord(outfile, dict)
    
  # initialize config object
  configObject = ConfigParser()
  
  configObject["RECORDINFO"] = {
   "numRecords": len(dataList),
   "numOverflow": 0,
   "recordSize": 106 # window users change to 107 
   }

  configObject["DATABASEINFO"] = {
   "name" : textFilename,
   "fieldNames": "NAME, RANK, CITY, STATE, ZIP, EMPLOYEES",
   "fieldTypes": "STRING, INT, STRING, STRING, INT, INT",
   "fieldSizes": "30, 10, 25, 10, 15, 15"
   }
  
  #Write the above specifications to config file
  with open(configFilename, 'w') as config:
   configObject.write(config)
  
  print("created " + textFilename + " & " + configFilename)
 
 else:
  print("error: cannot create database, input .csv file not found, try again.")
 
# testing
database = DB()
CreateDB("Fortune500Test", database)
database.Open("Fortune500Test")
database.AddRecord("f", "f", "f", "f", "f", "f")
database.UpdateRecord("f", "a", "a", "a", "a", "a")
database.Close()
database.Open("Fortune500Test")
database.AddRecord("z", "f", "f", "f", "f", "f")
database.UpdateRecord("z", "a", "a", "a", "a", "a")
database.Close()


