import os.path
import re
from configparser import ConfigParser

class DB:
 # default constructor
 def __init__(self):
  self.filestream = None
  self.record = None
  self.isOpen = False
  self.recordNum = -1
  self.numRecords = -1
  self.numOverflow = -1
  self.recordSize = -1
  
  
 def RemoveFileExtension(self, filename):
  return re.sub(r'\..*', '', filename)

 def RemoveTrailingWhitespace(self, inputString):
    pattern = r'\s+$'
    return re.sub(pattern, '', inputString)
 
 # Formatting files with spaces so each field is fixed length, i.e. ID field has a fixed length of 10
 def WriteRecord(self, filestream, dict):
  filestream.write("{:30.30}".format(dict["Name"]))
  filestream.write("{:10.10}".format(dict["Rank"]))
  filestream.write("{:25.25}".format(dict["City"]))
  filestream.write("{:10.10}".format(dict["State"]))
  filestream.write("{:15.15}".format(dict["Zip"]))
  filestream.write("{:15.15}".format(dict["Employees"]))
  filestream.write("\n")

 def AltWriteRecord(self, filestream, dict, position):
   filestream.seek(position)
   filestream.write("{:30.30}".format(dict["Name"]))
   filestream.write("{:10.10}".format(dict["Rank"]))
   filestream.write("{:25.25}".format(dict["City"]))
   filestream.write("{:10.10}".format(dict["State"]))
   filestream.write("{:15.15}".format(dict["Zip"]))
   filestream.write("{:15.15}".format(dict["Employees"]))
   filestream.write("\n")

 
 def Open(self, filename):
  tmpFilename = self.RemoveFileExtension(filename)
  self.filestream = tmpFilename + ".data"
  self.fileConfig = tmpFilename + ".config"
  
  # ensure .config & .data file is in path
  if os.path.isfile(self.fileConfig):
   if not os.path.isfile(self.filestream):
    print("error: cannot open database, .data file not found")
   else:
    # open database
    self.textFilename = open(self.filestream, 'r+')
    self.isOpen = True
   
    #Read .config file
    configObject = ConfigParser()
    configObject.read(tmpFilename + ".config")
    
    # set variables
    self.numRecords = int(configObject["RECORDINFO"]["numrecords"])
    self.numOverflow = int(configObject["RECORDINFO"]["numoverflow"])
    self.recordSize = int(configObject["RECORDINFO"]["recordsize"])
    
    print("opened database")
    
  else:
   print("error: cannot open database, .config file not found")
  
 def Close(self):
  if self.IsOpen():
   self.textFilename.close()
   self.isOpen = False
   self.filestream = None
   self.numRecords = -1
   self.numOverflow = -1
   self.recordSize = -1
   self.recordNum = -1
   self.record = None
   print("closed database")
  
 def IsOpen(self):
  return self.isOpen
 
 def ReadRecord(self, recordNum):
  if self.IsOpen():
   self.flag = False
   Name = Rank = City = State = Zip = Employees = "None"
   
   if recordNum >= 0 and recordNum < self.numRecords + self.numOverflow:
    self.textFilename.seek(0, 0)
    self.textFilename.seek(recordNum*self.recordSize)
    line = self.textFilename.readline().rstrip('\n')
    self.flag = True

   if self.flag:
    Name = self.RemoveTrailingWhitespace(line[0:30])
    Rank = self.RemoveTrailingWhitespace(line[30:40])
    City = self.RemoveTrailingWhitespace(line[40:65])
    State = self.RemoveTrailingWhitespace(line[65:75])
    Zip = self.RemoveTrailingWhitespace(line[75:90])
    Employees = self.RemoveTrailingWhitespace(line[90:105])

    self.record = dict({"Name":Name, "Rank":Rank, "City":City, "State":State, "Zip":Zip, "Employees":Employees})
    
    # print record for testing purposes 
    print("\nRecord " + str(recordNum))
    for key in self.record:
      print(key + ": " + self.record[key])
  
   else:
      print("error: record number "+ str(recordNum) +" out of range")
      
 def BinarySearch(self, key):
   if self.IsOpen():
     low = 0
     high = self.numRecords - 1
     self.found = False

     while high >= low:
      self.middle = (low+high)//2
      self.ReadRecord(self.middle)
      # print(self.record)
      midKey = self.record["Name"]

      if midKey == key:
        self.found = True
        return self.middle
      elif midKey > key:
        high = self.middle - 1
      elif midKey < key:
        low = self.middle + 1
     
     if not self.found:
       # try linear search at last
       for i in range (self.numRecords, 12):
         print(self.numRecords + self.numOverflow)
         self.ReadRecord(i)
         if self.record["Name"] == key:
          return i

       self.record = dict({"Name": "Name", "Rank": "Rank", "City": "City", "State": "State", "Zip": "Zip", "Employees": "Employees"})
       return -1
     
 def FindRecord(self, key):
   if self.IsOpen():
     self.recordNum = self.BinarySearch(key)
     if self.recordNum != -1:
       return True
     else:
       return False
   else:
     return False
   
 def UpdateRecord(self, name, rank, city, state, zip, employees):
   flag = False
   
   if self.IsOpen():
    if self.FindRecord(name):
      print(self.record)
      self.ReadRecord(self.recordNum)
      self.record = dict({"Name": name, "Rank": rank, "City": city, "State": state, "Zip": zip, "Employees": employees})
      self.AltWriteRecord(self.textFilename, self.record, self.recordNum * self.recordSize)
      flag = True

   return flag
 
 def DeleteRecord(self, key):

   if self.IsOpen():
     if self.FindRecord(key):
       self.ReadRecord(self.recordNum)
       self.record = dict({"Name": key, "Rank": "", "City": "", "State": "", "Zip": "", "Employees": ""})
       self.AltWriteRecord(self.textFilename, self.record, self.recordNum * self.recordSize)
       return True
     else:
       return False
   else:
     return False
   
 def AddRecord(self, name, rank, city, state, zip, employees):
   flag = False
   
   if self.IsOpen():
     config_object = ConfigParser()
     config_object.read(self.fileConfig)
     numOverflow = config_object["RECORDINFO"]["numoverflow"]
     config_object["RECORDINFO"]["numoverflow"] = str(int(numOverflow) + 1)
     self.numOverflow = int(numOverflow) + 1

     #Write changes back to file
     with open(self.fileConfig, 'w') as conf:
       config_object.write(conf)
     
     self.record = dict({"Name": name, "Rank": rank, "City": city, "State": state, "Zip": zip, "Employees": employees})
     self.AltWriteRecord(self.textFilename, self.record, (self.numRecords + self.numOverflow - 1) * self.recordSize)
     
     flag = True
  
   else:
     return flag

  
