import csv
import os.path

from configparser import ConfigParser
from Database import DB


def CreateDB(filename, databaseMethods):
 # generate fileames
 tmpFilename = databaseMethods.RemoveFileExtension(filename)
 csvFilename = tmpFilename + ".csv"
 textFilename = tmpFilename + ".data"
 configFilename = tmpFilename + ".config"
 
 if os.path.isfile(csvFilename):
  # Read the CSV file and write into data files
  with open(csvFilename, "r") as csvFile:
   dataList = list(csv.DictReader(csvFile, fieldnames=('Name', 'Rank', 'City', 'State', 'Zip', 'Employees')))
   
  with open(textFilename, "w") as outfile:
   for dict in dataList:
    databaseMethods.WriteRecord(outfile, dict)
    
  # initialize config object
  configObject = ConfigParser()
  
  configObject["RECORDINFO"] = {
   "numRecords": len(dataList),
   "numOverflow": 0,
   "recordSize": 116 # window users change to 107 
   }
  
  configObject["KEY"] = {
   "KEY" : "NAME",
   }

  configObject["DATABASEINFO"] = {
   "name" : textFilename,
   "fieldNames": "NAME, RANK, CITY, STATE, ZIP, EMPLOYEES",
   "fieldTypes": "STRING, INT, STRING, STRING, INT, INT",
   "fieldSizes": "40, 10, 25, 10, 15, 15"
   }
  
  #Write the above specifications to config file
  with open(configFilename, 'w') as config:
   configObject.write(config)
  
  print("created " + textFilename + " & " + configFilename)
 
 else:
  print("error: cannot create database, input .csv file not found, try again.")
 
# testing
if __name__ == "__main__":
  databaseMethods = DB()
  
  #menu
  while True:
    print("\n1. Create new database")
    print("2. Open database")
    print("3. Close database")
    print("4. Display record")
    print("5. Update record")
    print("6. Create report")
    print("7. Add record")
    print("8. Delete record")
    print("9. Quit\n")
    
    choice = input("Enter your choice: ")
    
    if choice == "1":
      filename = input("Enter csv filename: ")
      CreateDB(filename, databaseMethods)
    elif choice == "2":
      filename = input("Enter filename: ")
      databaseMethods.Open(filename)
    elif choice == "3":
      databaseMethods.Close()
    elif choice == "4":
      key = input("Enter key: ")
      databaseMethods.DisplayRecord(key)
    elif choice == "5":
      tmpvalue = ""
      value = input("Enter value: ")
      key = input("Enter key value: ")
      field = input("Enter fieldname: ")
      try:
        if field.lower() == "rank" or field.lower() == "zip" or field.lower() == "employees":
          tmpvalue = int(value)
        databaseMethods.UpdateRecords(value, key, field)
      except ValueError:
        print("error: Value does not match field type")
        pass
        
    elif choice == "6":
      databaseMethods.Report()
    elif choice == "7":
      flag = False
      while flag == False:
        tmprank = ""
        tmpzip = ""
        tmpemployees = ""
        
        name = input("Enter name (string): ")
        rank = input("Enter rank (int): ")
        city = input("Enter city (string): ")
        state = input("Enter state (string): ")
        zip = input("Enter zip (int): ")
        employees = input("Enter employees (int): ")
        try:
          tmprank = int(rank)
          tmpzip = int(zip)
          tmpemployees = int(employees)
        except ValueError:
          pass
        if isinstance(tmprank, int) and isinstance(tmpzip, int) and isinstance(tmpemployees, int):
          flag = True
        else:
          print("\nerror: Enter correct datatypes in fields\n")
      databaseMethods.AddRecord(name, rank, city, state, zip, employees)
    elif choice == "8":
      name = input("Enter key: ")
      databaseMethods.DeleteRecord(name)
    elif choice == "9":
      break
    else:
      print("\nChoice not available")
  


