import os.path
import re
from configparser import ConfigParser

class DB:
 # default constructor
 def __init__(self):
  self.filestream = None
  self.record = None
  self.isOpen = False
  self.recordNum = -1
  self.numRecords = -1
  self.numOverflow = -1
  self.recordSize = -1
  
  
 def RemoveFileExtension(self, filename):
  return re.sub(r'\..*', '', filename)

 def RemoveTrailingWhitespace(self, inputString):
    pattern = r'\s+$'
    return re.sub(pattern, '', inputString)
 
 # Formatting files with spaces so each field is fixed length, i.e. ID field has a fixed length of 10
 def WriteRecord(self, filestream, dict):
  filestream.write("{:40.40}".format(dict["Name"]))
  filestream.write("{:10.10}".format(dict["Rank"]))
  filestream.write("{:25.25}".format(dict["City"]))
  filestream.write("{:10.10}".format(dict["State"]))
  filestream.write("{:15.15}".format(dict["Zip"]))
  filestream.write("{:15.15}".format(dict["Employees"]))
  filestream.write("\n")

 def AltWriteRecord(self, filestream, dict, position):
   filestream.seek(position)
   filestream.write("{:40.40}".format(dict["Name"]))
   filestream.write("{:10.10}".format(dict["Rank"]))
   filestream.write("{:25.25}".format(dict["City"]))
   filestream.write("{:10.10}".format(dict["State"]))
   filestream.write("{:15.15}".format(dict["Zip"]))
   filestream.write("{:15.15}".format(dict["Employees"]))
   filestream.write("\n")

 
 def Open(self, filename):
  if not self.IsOpen():
    tmpFilename = self.RemoveFileExtension(filename)
    self.filestream = tmpFilename + ".data"
    self.fileConfig = tmpFilename + ".config"
  
    # ensure .config & .data file is in path
    if os.path.isfile(self.fileConfig):
      if not os.path.isfile(self.filestream):
        print("error: cannot open database, .data file not found")
      else:
        # open database
        self.textFilename = open(self.filestream, 'r+')
        self.isOpen = True
   
        #Read .config file
        configObject = ConfigParser()
        configObject.read(tmpFilename + ".config")
    
        # set variables
        self.numRecords = int(configObject["RECORDINFO"]["numrecords"])
        self.numOverflow = int(configObject["RECORDINFO"]["numoverflow"])
        self.recordSize = int(configObject["RECORDINFO"]["recordsize"])
        self.keyField = configObject["KEY"]["key"]
    
        print("opened database")
    
    else:
      print("error: cannot open database, .config file not found")
  else:
    print("error: close opened database first")
  
 def Close(self):
  # close database, reset instance variables
  if self.IsOpen():
    self.textFilename.close()
    self.isOpen = False
    self.filestream = None
    self.numRecords = -1
    self.numOverflow = -1
    self.recordSize = -1
    self.recordNum = -1
    self.record = None
    print("closed database")
  
 def IsOpen(self):
  return self.isOpen
 
 def ReadRecord(self, recordNum):
  # fill self.record with the record at recordNum
  if self.IsOpen():
   self.flag = False
   Name = Rank = City = State = Zip = Employees = "None"
   
   if recordNum >= 0 and recordNum < self.numRecords + self.numOverflow:
 
    self.textFilename.seek(0, 0)
    self.textFilename.seek(recordNum*self.recordSize)
    line = self.textFilename.readline().rstrip('\n')
    self.flag = True

   if self.flag:
    Name = self.RemoveTrailingWhitespace(line[0:40])
    Rank = self.RemoveTrailingWhitespace(line[40:50])
    City = self.RemoveTrailingWhitespace(line[50:75])
    State = self.RemoveTrailingWhitespace(line[75:85])
    Zip = self.RemoveTrailingWhitespace(line[85:100])
    Employees = self.RemoveTrailingWhitespace(line[100:115])

    self.record = dict({"Name":Name, "Rank":Rank, "City":City, "State":State, "Zip":Zip, "Employees":Employees})
    
    # print record for testing purposes 
    #print("\nRecord " + str(recordNum))
    #for key in self.record:
      #print(key + ": " + self.record[key])
  
   else:
      print("error: record number "+ str(recordNum) +" out of range")
      
 def __BinarySearch(self, key):
   if self.IsOpen():
     low = 0
     high = self.numRecords - 1
     self.found = False

     while high >= low:
      self.middle = (low+high)//2
      self.ReadRecord(self.middle)
      # print(self.record)
      midKey = self.record["Name"]

      if midKey == key:
        self.found = True
        return self.middle
      elif midKey > key:
        high = self.middle - 1
      elif midKey < key:
        low = self.middle + 1
     
     #extension if not found in sorted part
     if not self.found:
       # try linear search at last
       for i in range (self.numRecords, self.numRecords + self.numOverflow):
         self.ReadRecord(i)
         if self.record["Name"] == key:
          return i

       self.record = dict({"Name": "Name", "Rank": "Rank", "City": "City", "State": "State", "Zip": "Zip", "Employees": "Employees"})
       return -1
     
 def __FindRecord(self, key):
   # find record with key and fill self.record with the parameters
   if self.IsOpen():
     self.recordNum = self.__BinarySearch(key)
     if self.recordNum != -1:
       return True
     else:
       return False
   else:
     return False
   
 def UpdateRecord(self, value, key, field):
   # update a row with the exact key in the field with value
   flag = False
   
   if self.IsOpen():
    if self.__FindRecord(key):
      self.ReadRecord(self.recordNum)
      altField = field.lower()
      altField = altField.capitalize()
      if altField in self.record:
        self.record[altField] = value
        self.AltWriteRecord(self.textFilename, self.record, self.recordNum * self.recordSize)
        flag = True

    else:
      print("error: key value does not exist")
   return flag
 
 def DeleteRecord(self, key):
   # leaves key the same but deletes other fields 
   if self.IsOpen():
     if self.__FindRecord(key):
       self.ReadRecord(self.recordNum)
       self.record = dict({"Name": key, "Rank": "", "City": "", "State": "", "Zip": "", "Employees": ""})
       self.AltWriteRecord(self.textFilename, self.record, self.recordNum * self.recordSize)
       return True
     else:
       return False
   else:
     print("error: open database")
     return False
   
 def AddRecord(self, name, rank, city, state, zip, employees):
   #adds record to the end of .data file and increments numOverflow by one
   flag = False
   
   if self.IsOpen():
     config_object = ConfigParser()
     config_object.read(self.fileConfig)
     numOverflow = config_object["RECORDINFO"]["numoverflow"]
     config_object["RECORDINFO"]["numoverflow"] = str(int(numOverflow) + 1)
     self.numOverflow = int(numOverflow) + 1

     #Write changes back to file
     with open(self.fileConfig, 'w') as conf:
       config_object.write(conf)
     
     self.record = dict({"Name": name, "Rank": rank, "City": city, "State": state, "Zip": zip, "Employees": employees})
     self.AltWriteRecord(self.textFilename, self.record, (self.numRecords + self.numOverflow - 1) * self.recordSize)
     
     flag = True
  
   else:
     return flag
   
 def DisplayRecord(self, key):
  # finds record by key and displays it
  if self.IsOpen():
    if not self.__FindRecord(key):
      print("No such company")
    else:
      deleted = False
      for key in self.record:
        if self.record[key] == "":
          deleted = True
      if not deleted:
        print("\nRecord " + str(self.recordNum))
        for key in self.record:
          print(key + ": " + self.record[key])
      else:
        print("error: that record is deleted")
  else:
    print("Open the database first")

  
 def UpdateRecords(self, value, key, field):
  # public method of update record
  if self.IsOpen():
    config_object = ConfigParser()
    config_object.read(self.fileConfig)
    if field.upper() == config_object["KEY"]["key"]:
      print("You cannot edit the primary key")
    else:
      self.UpdateRecord(value, key, field)
      
 def Report(self):
   # print 10 records excluding the ones deleted

   validRecords = 0
   for i in range(self.numRecords + self.numOverflow):
     if validRecords == 10:
       # we have created the report
       break
     # read record at position i
     self.ReadRecord(i)
     if not self.record["Rank"] == "":
       validRecords = validRecords + 1
       print("\nRecord " + str(i + 1) + ":")
       for key in self.record:
         print(key + ": " + self.record[key])